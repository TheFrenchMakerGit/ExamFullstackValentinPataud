export interface RestaurantDto {
    id: number;
    nom: string;
    adresse: string;
    evaluations: EvaluationDto[];
    evaluation_finale?: EvaluationFianleDto;
    tags : TagDto[];
    moyenne:number
}

export interface EvaluationDto {
    id: number;
    nom: string;
    note: number;
    texte: string;
    creation: string;
    modification:string;

}

export interface EvaluationFianleDto {
  id:number;
  nom:string;
  texte:string;
  vote:number;

}

export interface TagDto{
  id:number
  texte : string;
}

export interface addEvaluationDto {
  nom: string;
  texte: string;
  note: number;
}

export interface addEvaluationFinaleDto {
  nom: string;
  texte: string;
  vote: number;
}
export interface addRestaurantDto {
  nom: string;
  adresse: string;
}
export interface addTagDto {
  texte: string;
}
export interface linkTagDto {
  tagsId: number[];
}

export interface urlDto{
  url:string;
}
