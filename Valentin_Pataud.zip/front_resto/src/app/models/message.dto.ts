export interface MessageDto {
    code: string,
    message: string
}
