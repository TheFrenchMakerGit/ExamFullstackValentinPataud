import {Injectable} from "@angular/core"
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import {addRestaurantDto, RestaurantDto, urlDto} from "../models/RestaurantDto";
import { MessageDto } from '../models/message.dto';

@Injectable({
    providedIn: 'root'
})
export class RestaurantService {
    constructor(private httpClient: HttpClient) {

    }

    public getRestaurants(): Observable<RestaurantDto[]> {
        return this.httpClient.get<RestaurantDto[]>(`http://localhost:8080/restaurants`)
    }
    public getRestaurantById(id:string): Observable<RestaurantDto> {
      return this.httpClient.get<RestaurantDto>(`http://localhost:8080/restaurants/${id}`)
    }
    getPresignedUrl(id: string): Observable<urlDto> {
        return this.httpClient.get<urlDto>(`http://localhost:8080/restaurants/${id}/cover`);
    }

  public addRestaurant(newData: addRestaurantDto): Observable<RestaurantDto> {
    return this.httpClient.post<RestaurantDto>(`http://localhost:8080/restaurants`, newData);
  }

}
