import {Component, Input} from '@angular/core';
import { CommonModule } from '@angular/common';
import { RestaurantService } from '../../services/restaurant.service';
import {switchMap, Observable, concat} from 'rxjs';
import { MessageDto } from '../../models/message.dto';
import { ActivatedRoute } from '@angular/router';
import {RestaurantDto} from "../../models/RestaurantDto";
import {TableYellowOrRedDirective} from "../../directives/table-yellow-or-red.directive";

@Component({
  selector: 'app-detail-page',
  standalone: true,
  imports: [CommonModule, TableYellowOrRedDirective],
  templateUrl: './detail-page.component.html',
  styleUrl: './detail-page.component.css'
})
export class DetailPageComponent {

  public image : string = "";

  @Input()
  public resto ?: RestaurantDto;
  private id : string = this.activatedRoute.snapshot.params["id"]

  constructor(private restaurantService : RestaurantService, private activatedRoute : ActivatedRoute) {

  }

  ngOnInit(): void {
    this.restaurantService.getPresignedUrl(this.id).subscribe({
      next: image => this.image = image.url
    })
    this.restaurantService.getRestaurantById(this.id).subscribe({
      next: resto => this.resto = resto
    })
}

  protected readonly concat = concat;
}
