import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RestaurantDto } from '../../models/RestaurantDto';
import { TableRestaurantsComponent } from "../../components/table-restaurants/table-restaurants.component";
import { RestaurantService } from '../../services/restaurant.service';
import {AddRestaurantFormComponent} from "../../components/add-restaurant-form/add-restaurant-form.component";

@Component({
    selector: 'app-home-page',
    standalone: true,
    templateUrl: './home-page.component.html',
    styleUrl: './home-page.component.css',
  imports: [CommonModule, TableRestaurantsComponent, AddRestaurantFormComponent]
})
export class HomePageComponent {

  public restos : RestaurantDto[] = [];

  constructor(private restaurantService : RestaurantService) {

  }

    ngOnInit(): void {
        this.restaurantService.getRestaurants().subscribe({
            next: restos => this.restos = restos
        })
    }

}
