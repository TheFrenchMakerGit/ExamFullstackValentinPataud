import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RestaurantDto } from '../../models/RestaurantDto';
import { Router } from '@angular/router';
import { TableYellowOrRedDirective } from '../../directives/table-yellow-or-red.directive';

@Component({
  selector: 'app-table-restaurant',
  standalone: true,
  imports: [CommonModule, TableYellowOrRedDirective],
  templateUrl: './table-restaurants.component.html',
  styleUrl: './table-restaurants.component.css'
})

export class TableRestaurantsComponent {

  navigateToDetails(id: number) {
    this.router.navigate([`restaurants/${id}`])
  }

  @Input()
  public restos: RestaurantDto[] = [];

  constructor(private readonly router: Router) {
  }
}
