import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TableRestaurantsComponent } from './table-restaurants.component';

describe('TableRestaurantComponent', () => {
  let component: TableRestaurantsComponent;
  let fixture: ComponentFixture<TableRestaurantsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TableRestaurantsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TableRestaurantsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
