import {Component, EventEmitter, Output} from '@angular/core';
import { CommonModule } from '@angular/common';
import {FormsModule, NgForm} from "@angular/forms";
import {addRestaurantDto} from "../../models/RestaurantDto";

@Component({
  selector: 'app-add-restaurant-form',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './add-restaurant-form.component.html',
  styleUrl: './add-restaurant-form.component.css'
})
export class AddRestaurantFormComponent {
  @Output("RestoSubmitted") RestaurantSubmittedEmiter = new EventEmitter<addRestaurantDto>();

  public formData: addRestaurantDto = {
    nom: "",
    adresse:""
  }

  public submit(form: NgForm): void {
    if (form.valid) {
      this.RestaurantSubmittedEmiter.emit(this.formData);
    }
  }
}
