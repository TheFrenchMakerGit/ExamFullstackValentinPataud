1- Pour mettre à jour la photo, il faudrit supprimer l'ancienne et en uploader une autre. Il n'y a pas de route dediée.
2- Pour stocker les illustrations, il faudrait stocker les id des images dans un table dédiée.
3- Retourner l'image à l'affichage du resto peut être fait. Le processus ne consomme pas beacoup de temps et de ressources et est asynchrone
donc même si le telechargement prend du temps, la page ne freeze pas
4- Il est aussi interessant de retourner l'evaluation fianle à chaque fois. Cela est pertinent dans l'affichage des infos du restaurant
5- Pour stocker les tags, j'ai créer une table tag avec un champ texte et un id. Les tags sont liés aux restaurants à l'aide d'une jointure
many to many. Cela permet de modifier et d'ajouter des tags au besoin. C'est la solution la plus longue à mettre en place, mais c'est la meilleur.