package restaurant.back_restaurants.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import restaurant.back_restaurants.entity.Tag;

@Repository
public interface RepoTag extends JpaRepository<Tag, Integer> {
}
