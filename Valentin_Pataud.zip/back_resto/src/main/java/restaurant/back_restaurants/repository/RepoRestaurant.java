package restaurant.back_restaurants.repository;


import restaurant.back_restaurants.entity.Restaurant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RepoRestaurant extends JpaRepository<Restaurant, Integer> {
}
