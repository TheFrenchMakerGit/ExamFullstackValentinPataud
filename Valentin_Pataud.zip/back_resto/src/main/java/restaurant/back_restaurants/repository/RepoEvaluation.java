package restaurant.back_restaurants.repository;

import restaurant.back_restaurants.entity.Evaluation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RepoEvaluation extends JpaRepository<Evaluation, Integer> {
}