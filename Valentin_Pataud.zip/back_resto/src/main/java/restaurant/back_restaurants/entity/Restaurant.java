package restaurant.back_restaurants.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Optional;

@Entity(name = "serie")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Restaurant {

    @Id
    @GeneratedValue()
    private Integer restoid;

    @Column(name = "nom", columnDefinition = "varchar(90)", nullable = false)
    private String nom;

    @Column(name = "adresse", columnDefinition = "varchar(255)", nullable = false)
    private String adresse;

    @OneToMany(mappedBy = "restaurant")
    private List<Evaluation> evaluations;

    @OneToOne(mappedBy = "restaurant")
    private EvaluationFinale evaluationFinale;

    @ManyToMany(mappedBy = "restaurants")
    private List<Tag>  tags;

}
