package restaurant.back_restaurants.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Entity(name = "evaluation")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Evaluation {
    @Id
    @GeneratedValue()
    private Integer evalid;

    @Column(name = "nom", columnDefinition = "varchar(50)", nullable = false)
    private String nom;

    @Column(name = "com", columnDefinition = "varchar(255)", nullable = false)
    private String com;

    @ManyToOne
    @JoinColumn(name = "restoid")
    private Restaurant restaurant;

    @Column(name = "note")
    @Min(0)
    @Max(3)
    private Integer note;

    @Column(name = "creation_date", columnDefinition = "DATE")
    private LocalDate creation;

    @Column(name = "modification_date", columnDefinition = "DATE")
    private LocalDate modif;
}
