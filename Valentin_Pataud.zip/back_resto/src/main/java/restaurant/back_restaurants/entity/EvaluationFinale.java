package restaurant.back_restaurants.entity;


import jakarta.persistence.*;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity(name = "evaluation_finale")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EvaluationFinale {

    @Id
    @GeneratedValue()
    private Integer finaleid;

    @Column(name = "nom", columnDefinition = "varchar(90)", nullable = false)
    private String nom;

    @OneToOne
    @JoinColumn(name = "restoid")
    private Restaurant restaurant;

    @Column(name = "vote")
    @Min(0)
    @Max(3)
    private Integer vote;

    @Column(name = "texte", columnDefinition = "LONGTEXT", nullable = false)
    private String texte;

}
