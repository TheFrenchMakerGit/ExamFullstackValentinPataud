package restaurant.back_restaurants.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Entity(name = "tag")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Tag {
    @Id
    @GeneratedValue()
    private Integer tagid;

    @Column(name = "text", columnDefinition = "varchar(50)", nullable = false)
    private String tag;

    @ManyToMany
    @JoinTable(name = "restaurants_in_tags",
            joinColumns = @JoinColumn(name = "tags"),
            inverseJoinColumns = @JoinColumn(name = "restaurants"))
    private List<Restaurant> restaurants;


}
