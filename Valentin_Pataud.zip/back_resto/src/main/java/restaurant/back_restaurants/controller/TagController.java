package restaurant.back_restaurants.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import restaurant.back_restaurants.dto.request.linkTagDto;
import restaurant.back_restaurants.dto.response.RestaurantDto;
import restaurant.back_restaurants.dto.response.TagDto;
import restaurant.back_restaurants.service.TagService;
import restaurant.back_restaurants.dto.request.addTagDto;

import java.util.List;

@RestController

@RequiredArgsConstructor
@Slf4j
@CrossOrigin(origins = "*")
public class TagController {

    private final TagService tagService;

    @PostMapping("/tags")
    public TagDto addEvaluation(@Valid @RequestBody addTagDto dto) {
        return TagDto.buildFromEntity(this.tagService.addTag(dto));
    }
    @GetMapping("/tags")
    public List<TagDto> getTags(){
        return this.tagService.getTag().stream().map(tagDto -> TagDto.buildFromEntity(tagDto)).toList();
    }
    @PostMapping("/restaurants/{id}/tags")
    public List<TagDto> getRestaurantCoverById(@PathVariable Integer id, @Valid @RequestBody linkTagDto dto) {
        return this.tagService.addTagsToRestaurant(id,dto).stream().map(tagdto -> TagDto.buildFromEntity(tagdto)).toList();
    }

}