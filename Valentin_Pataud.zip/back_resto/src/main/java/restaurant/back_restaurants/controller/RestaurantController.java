package restaurant.back_restaurants.controller;

import restaurant.back_restaurants.dto.request.addRestaurantDto;
import restaurant.back_restaurants.dto.request.linkTagDto;
import restaurant.back_restaurants.dto.response.RestaurantDto;
import restaurant.back_restaurants.dto.response.TagDto;
import restaurant.back_restaurants.dto.response.UrlDto;
import restaurant.back_restaurants.service.RestaurantService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequiredArgsConstructor
@Slf4j
@CrossOrigin(origins = "*")
public class RestaurantController {

    private final RestaurantService restaurantService;
    @GetMapping("/restaurants")
    public List<RestaurantDto> getRestaurants(@RequestParam(value = "id", required = false) ArrayList<Integer> idsToFetch) {
        if (idsToFetch == null || idsToFetch.isEmpty()) {
            return this.restaurantService.getRestaurants().stream().map(restoEntity -> RestaurantDto.buildFromEntity(restoEntity)).toList();
        } else {
            return this.restaurantService.getRestaurantsByIds(idsToFetch).stream().map(restoEntity -> RestaurantDto.buildFromEntity(restoEntity)).toList();
        }
    }

    @GetMapping("/restaurants/{id}")
    public RestaurantDto getRestaurantById(@PathVariable Integer id) {
        return RestaurantDto.buildFromEntity(this.restaurantService.getRestaurantById(id));
    }

    @PostMapping("/restaurants")
    public RestaurantDto addRestaurant(@Valid @RequestBody addRestaurantDto addRestaurantDto) {
        return RestaurantDto.buildFromEntity(this.restaurantService.addRestaurant(addRestaurantDto));
    }

    @DeleteMapping("/restaurants/{id}")
    public void deleteRestaurant(@PathVariable Integer id) {
        this.restaurantService.deleteRestaurant(id);
    }

    @GetMapping("/restaurants/{id}/cover")
    public UrlDto getRestaurantCoverById(@PathVariable Integer id) {
        return UrlDto.builder().url(this.restaurantService.getCoverDownloadUrl(id)).build();
    }


    @PutMapping("/restaurants/{id}/cover")
    public UrlDto putRestaurantCoverById(@PathVariable Integer id) {
        return UrlDto.builder().url(this.restaurantService.putCoverDownloadUrl(id)).build();
    }
}
