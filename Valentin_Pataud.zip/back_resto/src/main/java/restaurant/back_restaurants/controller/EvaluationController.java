package restaurant.back_restaurants.controller;

import restaurant.back_restaurants.dto.request.addEvaluationDto;
import restaurant.back_restaurants.dto.response.EvaluationDto;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import restaurant.back_restaurants.service.EvaluationService;

@RestController

@RequiredArgsConstructor
@Slf4j
@CrossOrigin(origins = "*")
public class EvaluationController {

    private final EvaluationService evaluationService;

    @PostMapping("/restaurants/{Id}/evaluations")
    public EvaluationDto addEvaluation(@PathVariable Integer Id, @Valid @RequestBody addEvaluationDto addEvaluationDto) {
        return EvaluationDto.buildFromEntity(this.evaluationService.addEvaluationToRestaurant(Id, addEvaluationDto));
    }

}