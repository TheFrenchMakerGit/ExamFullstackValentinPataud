package restaurant.back_restaurants.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import restaurant.back_restaurants.service.EvaluationFinaleService;
import restaurant.back_restaurants.dto.request.addEvaluationFinaleDto;
import restaurant.back_restaurants.dto.response.EvaluationFinaleDto;

@RestController

@RequiredArgsConstructor
@Slf4j
@CrossOrigin(origins = "*")
public class EvaluationFinalController {

    private final EvaluationFinaleService evaluationFinaleService;

    @PostMapping("/restaurants/{Id}/evaluationfinale")
    public EvaluationFinaleDto addEvaluationFinale(@PathVariable Integer Id, @Valid @RequestBody addEvaluationFinaleDto dto) {
        return EvaluationFinaleDto.buildFromEntity(this.evaluationFinaleService.addEvaluationFinaleToRestaurant(Id, dto));
    }

}