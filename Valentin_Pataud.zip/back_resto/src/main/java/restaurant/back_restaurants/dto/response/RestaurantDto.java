package restaurant.back_restaurants.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import restaurant.back_restaurants.entity.Restaurant;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RestaurantDto {

    @JsonProperty("id")
    private Integer id;

    @JsonProperty("nom")
    private String nom;

    @JsonProperty("adresse")
    private String adresse;

    @JsonProperty("evaluations")
    private List<EvaluationDto> evaluationDtos;

    @JsonProperty("tags")
    private List<TagDto> tags;

    @JsonProperty("evaluation_finale")
    private EvaluationFinaleDto evaluationFinaleDto;

    @JsonProperty("moyenne")
    private Double moyenne;

    public static RestaurantDto buildFromEntity(Restaurant restaurantEntity) {
        return RestaurantDto.builder()
                .id(restaurantEntity.getRestoid())
                .nom(restaurantEntity.getNom())
                .adresse(restaurantEntity.getAdresse())
                .evaluationFinaleDto(EvaluationFinaleDto.buildFromEntity(restaurantEntity.getEvaluationFinale()))
                .evaluationDtos(restaurantEntity.getEvaluations().stream().map(evaluation -> EvaluationDto.buildFromEntity(evaluation)).toList())
                .tags(restaurantEntity.getTags().stream().map(tagEntity -> TagDto.buildFromEntity(tagEntity)).toList())
                .moyenne(restaurantEntity.getEvaluations().stream().mapToDouble(note -> note.getNote()).average().orElse(0)) // Calcul la moyenne des notes et retourne un double. Sinon retourner 0
                .build();
    }

}