package restaurant.back_restaurants.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import restaurant.back_restaurants.entity.Evaluation;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EvaluationDto {

    @JsonProperty("id")
    private Integer id;

    @JsonProperty("texte")
    private String texte;

    @JsonProperty("nom")
    private String nom;

    @JsonProperty("note")
    private Integer note;

    @JsonProperty("date_creation")
    private LocalDate creation;

    @JsonProperty("date_modification")
    private LocalDate modification;


    public static EvaluationDto buildFromEntity(Evaluation evaluationEntity) {
        return EvaluationDto.builder()
                .id(evaluationEntity.getEvalid())
                .nom(evaluationEntity.getNom())
                .creation(evaluationEntity.getCreation())
                .modification(evaluationEntity.getModif())
                .note(evaluationEntity.getNote())
                .texte(evaluationEntity.getCom()).build();

    }

}