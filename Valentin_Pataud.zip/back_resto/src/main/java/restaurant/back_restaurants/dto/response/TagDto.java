package restaurant.back_restaurants.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import restaurant.back_restaurants.entity.Tag;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TagDto {

    @JsonProperty("id")
    private Integer id;

    @JsonProperty("texte")
    private String texte;

    public static TagDto buildFromEntity(Tag tag) {
        return TagDto.builder()
                .id(tag.getTagid())
                .texte(tag.getTag()).build();
    }

}