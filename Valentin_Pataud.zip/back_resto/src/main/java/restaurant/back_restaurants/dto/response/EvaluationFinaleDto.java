package restaurant.back_restaurants.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import restaurant.back_restaurants.entity.EvaluationFinale;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EvaluationFinaleDto {

    @JsonProperty("id")
    private Integer id;

    @JsonProperty("nom")
    private String nom;

    @JsonProperty("vote")
    private Integer vote;

    @JsonProperty("texte")
    private String texte;

    public static EvaluationFinaleDto buildFromEntity(EvaluationFinale evaluationFinale) {
        if(evaluationFinale == null) return null; // S'il n'y a pas d'evaluation finale, ne la construit pas
        return EvaluationFinaleDto.builder()
                .id(evaluationFinale.getFinaleid())
                .texte(evaluationFinale.getTexte())
                .nom(evaluationFinale.getNom())
                .vote(evaluationFinale.getVote())
                .build();
    }

}