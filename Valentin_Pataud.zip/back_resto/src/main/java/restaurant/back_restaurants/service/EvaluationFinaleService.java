package restaurant.back_restaurants.service;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import restaurant.back_restaurants.dto.request.addEvaluationFinaleDto;
import restaurant.back_restaurants.entity.EvaluationFinale;
import restaurant.back_restaurants.entity.Restaurant;
import restaurant.back_restaurants.exception.ResourceNotFoundException;
import restaurant.back_restaurants.repository.RepoEvaluationFinale;

@Service
@Slf4j
@AllArgsConstructor
public class EvaluationFinaleService {

    private final RepoEvaluationFinale repoEvaluationFinale;
    private final RestaurantService restaurantService;

    public EvaluationFinale getEvaluationFinaleById(final Integer id) {
        return this.repoEvaluationFinale.findById(id).orElseThrow(() -> new ResourceNotFoundException("Comm with id " + id + " + not found"));
    }

    public EvaluationFinale addEvaluationFinaleToRestaurant(final Integer restoId, final addEvaluationFinaleDto dto) {
        final Restaurant restaurant = this.restaurantService.getRestaurantById(restoId);

        final EvaluationFinale evaluation = EvaluationFinale.builder()
                .texte(dto.getTexte())
                .vote(dto.getVote())
                .nom(dto.getNom())
                .restaurant(restaurant).build();

        return this.repoEvaluationFinale.save(evaluation);
    }
}
