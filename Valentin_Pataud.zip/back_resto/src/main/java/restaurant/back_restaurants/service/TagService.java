package restaurant.back_restaurants.service;

import restaurant.back_restaurants.dto.request.addTagDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import restaurant.back_restaurants.dto.request.linkTagDto;
import restaurant.back_restaurants.entity.Restaurant;
import restaurant.back_restaurants.entity.Tag;
import restaurant.back_restaurants.exception.ResourceNotFoundException;
import restaurant.back_restaurants.repository.RepoTag;

import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class TagService {

    private final RepoTag repo;
    private final RestaurantService restaurantService;
    public List<Tag> getTag() {
        return this.repo.findAll();
    }
    public List<Tag> getTagByIds(final List<Integer> idsToFetch) {
        return this.repo.findAllById(idsToFetch);
    }

    public Tag getTagById(final Integer id) {
        return this.repo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Tag with id " + id + " + not found"));
    }

    public Tag addTag(final addTagDto tagDto) {
        final Tag tagToInsert = Tag.builder().tag(tagDto.getTexte()).build();

        return this.repo.save(tagToInsert);
    }
    public List<Tag> addTagsToRestaurant(final Integer restoId, final linkTagDto tagIds) {


        List<Tag> tags = this.repo.findAllById(tagIds.getTagsId());
        Restaurant restaurant = this.restaurantService.getRestaurantById(restoId);
        for(Tag t : tags)
        {
            List<Restaurant> resto = t.getRestaurants();
            resto.add(restaurant);
            t.setRestaurants(resto);
            this.repo.save(t);
        }


        return tags;
    }

}
