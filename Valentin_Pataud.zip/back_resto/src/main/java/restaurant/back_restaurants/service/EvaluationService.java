package restaurant.back_restaurants.service;

import restaurant.back_restaurants.dto.request.addEvaluationDto;
import restaurant.back_restaurants.entity.Evaluation;
import restaurant.back_restaurants.entity.Restaurant;
import restaurant.back_restaurants.exception.InvalidValueException;
import restaurant.back_restaurants.exception.ResourceNotFoundException;
import restaurant.back_restaurants.repository.RepoEvaluation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
@Slf4j
@AllArgsConstructor
public class EvaluationService {

    private final RepoEvaluation repoEvaluation;
    private final RestaurantService restaurantService;

    public Evaluation getEvaluationById(final Integer id) {
        return this.repoEvaluation.findById(id).orElseThrow(() -> new ResourceNotFoundException("Evaluation with id " + id + " + not found"));
    }

    public Evaluation addEvaluationToRestaurant(final Integer restoId, final addEvaluationDto dto) {
        if (dto.getNom() == null) {
            throw new InvalidValueException("Le nom ne doit pas être null");
        }
        if (dto.getNote() == null) {
            throw new InvalidValueException("La note ne doit pas être null");
        }
        final Restaurant restaurant = this.restaurantService.getRestaurantById(restoId);
        final Evaluation evaluation = Evaluation.builder()
                .com(dto.getTexte())
                .nom(dto.getNom())
                .note(dto.getNote())
                .creation(LocalDate.now())
                .modif(LocalDate.now())
                .restaurant(restaurant).build();

        return this.repoEvaluation.save(evaluation);
    }

    public Evaluation updateEvaluation(final Integer id, final addEvaluationDto dto)
    {
        if (dto.getNom() == null) {
            throw new InvalidValueException("le nouveau nom ne doit pas être null");
        }
        if (dto.getNote() == null) {
            throw new InvalidValueException("la nouvelle note ne doit pas être null");
        }
        final Evaluation eval = this.repoEvaluation.findById(id).orElseThrow(() -> new ResourceNotFoundException("l'evaluation d'id " + id + " n'existe pas"));
        eval.setNom(dto.getNom());
        eval.setCom(dto.getTexte());
        eval.setNote(dto.getNote());
        eval.setModif(LocalDate.now());
        this.repoEvaluation.save(eval);
        return eval;
    }

    public void deleteEvaluation(final Integer Id){
        this.repoEvaluation.deleteById(Id);
    }
}
