package restaurant.back_restaurants.service;

import restaurant.back_restaurants.dto.request.linkTagDto;
import restaurant.back_restaurants.dto.response.TagDto;
import restaurant.back_restaurants.entity.EvaluationFinale;
import restaurant.back_restaurants.entity.Restaurant;
import restaurant.back_restaurants.entity.Tag;
import restaurant.back_restaurants.repository.RepoRestaurant;
import restaurant.back_restaurants.dto.request.addRestaurantDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import restaurant.back_restaurants.exception.InvalidValueException;
import restaurant.back_restaurants.exception.ResourceNotFoundException;

import java.util.Collections;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class RestaurantService {

    private final RepoRestaurant repo;
    private final S3Service s3Service;

    public List<Restaurant> getRestaurants() {
        return this.repo.findAll();
    }

    public List<Restaurant> getRestaurantsByIds(final List<Integer> idsToFetch) {
        return this.repo.findAllById(idsToFetch);
    }

    public Restaurant getRestaurantById(final Integer id) {
        return this.repo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Restaurant with id " + id + " + not found"));
    }

    public Restaurant addRestaurant(final addRestaurantDto resto) {
        final Restaurant restaurantToInsert = Restaurant.builder()
                .nom(resto.getNom())
                .adresse(resto.getAdresse())
                .evaluations(Collections.emptyList())
                .tags(Collections.emptyList()).build();

        return this.repo.save(restaurantToInsert);
    }

    public void deleteRestaurant(final Integer id) {
        this.repo.deleteById(id);
    }

    public Restaurant updateRestaurant(int id, String nouveauNom, String nouvelleAdresse) {
        if (nouveauNom == null) {
            throw new InvalidValueException("le nouveau nom ne doit pas être null");
        }
        if (nouvelleAdresse == null) {
            throw new InvalidValueException("la nouvelle adresse ne doit pas être null");
        }
        final Restaurant restaurantToUpdate = this.repo.findById(id).orElseThrow(() -> new ResourceNotFoundException("le restaurant d'id " + id + " n'existe pas"));
        restaurantToUpdate.setNom(nouveauNom);
        restaurantToUpdate.setAdresse(nouvelleAdresse);
        repo.save(restaurantToUpdate);
        return restaurantToUpdate;
    }

    public String getCoverDownloadUrl(final Integer restoId) {
        this.getRestaurantById(restoId);

        return this.s3Service.getDownloadUrl("VALENTIN_RESTO_" + restoId);
    }

    public String putCoverDownloadUrl(final Integer restoId) {
        this.getRestaurantById(restoId);

        return this.s3Service.putDownloadUrl("VALENTIN_RESTO_" + restoId);
    }

}
