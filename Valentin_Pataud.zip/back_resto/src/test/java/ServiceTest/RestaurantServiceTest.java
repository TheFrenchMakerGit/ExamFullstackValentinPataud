package ServiceTest;

import restaurant.back_restaurants.entity.Restaurant;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import restaurant.back_restaurants.exception.InvalidValueException;
import restaurant.back_restaurants.repository.RepoRestaurant;
import restaurant.back_restaurants.service.RestaurantService;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class RestaurantServiceTest {

    @Mock
    private RepoRestaurant repoRestaurant;

    @InjectMocks
    private RestaurantService restaurantService;

    @Test
    public void update_resto_with_null_name() {
        assertThrows(InvalidValueException.class, () -> this.restaurantService.updateRestaurant(0, null, "adresse"));
    }

    @Test
    public void update_resto_with_null_adresse() {
        assertThrows(InvalidValueException.class, () -> this.restaurantService.updateRestaurant(0, "nom", null));
    }


    @Test
    public void update_restaurant_ok() {
        when(this.repoRestaurant.findById(anyInt())).thenReturn(Optional.of(Restaurant.builder().build()));
        final Restaurant result = this.restaurantService.updateRestaurant(123, "toto", "adresse");

        assertEquals("toto", result.getNom());
        assertEquals("adresse", result.getAdresse());
    }
}
