package ServiceTest;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import restaurant.back_restaurants.dto.request.addEvaluationDto;
import restaurant.back_restaurants.entity.Evaluation;
import restaurant.back_restaurants.exception.InvalidValueException;
import restaurant.back_restaurants.repository.RepoEvaluation;
import restaurant.back_restaurants.service.EvaluationService;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class EvaluationServiceTest {

    @Mock
    private RepoEvaluation repoEvaluation;

    @InjectMocks
    private EvaluationService evaluationService;

    @Test
    public void update_eval_with_null_name() {
        assertThrows(InvalidValueException.class, () -> this.evaluationService.updateEvaluation(0, addEvaluationDto.builder().nom(null).build()));
    }


    @Test
    public void update_eval_with_null_note() {
        assertThrows(InvalidValueException.class, () -> this.evaluationService.updateEvaluation(0, addEvaluationDto.builder().note(null).build()));
    }


    @Test
    public void update_eval_ok() {
        when(this.repoEvaluation.findById(anyInt())).thenReturn(Optional.of(Evaluation.builder().build()));
        final Evaluation result = this.evaluationService.updateEvaluation(123, addEvaluationDto.builder().nom("kevin").note(2).texte("muskatnuss").build());

        assertEquals("kevin", result.getNom());
        assertEquals(2, result.getNote());
        assertEquals("muskatnuss", result.getCom());
    }
}
